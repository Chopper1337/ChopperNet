Place the patch in the installation directory of ProcessLasso
Close ProcessLasso and anything related to it
Run Patch.exe as admin and click "PATCH"
ProcessLasso should be activated

If it did not work, retry but with ProcessLasso running, or just buy it...