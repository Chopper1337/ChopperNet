cls
echo "Downloading latest release..."
$url = "https://ci.appveyor.com/api/projects/benvanik/xenia/artifacts/xenia_master.zip?branch=master&job=Configuration%3A%20Release&pr=false"
$output = "$PSScriptRoot\xenia_master.zip"
$start_time = Get-Date
Invoke-WebRequest -Uri $url -OutFile $output
Write-Output "Time taken: $((Get-Date).Subtract($start_time).Seconds) second(s)"
cls
echo "Deleteing xenia.exe, xenia.pdb and LICENSE"
Remove-Item 'xenia.exe'
Remove-Item 'xenia.pdb'
Remove-Item 'LICENSE'
cls
echo "Extracting xenia_master.zip..."
echo "This zip will be deleted afterwards"
Expand-Archive -LiteralPath 'xenia_master.zip' -DestinationPath .
Remove-Item 'xenia_master.zip'
cls
echo "Created by Chopper1337"
echo "This updater is in no way affiliated with Xenia"
echo "Thank you for using my program!"
pause