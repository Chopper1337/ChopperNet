Place the Xenia.ps1 file in your Xenia directory (Where you store xenia.exe)
Right click and run in powershell.
Edit the powershell script file as you wish.

You can download a PS1 to EXE converter to convert it to an exe but I don't know if it'll work

I would use Fatih Kodak's "Ps1 To Exe v3.1"
https://www.majorgeeks.com/files/details/ps1_to_exe.html